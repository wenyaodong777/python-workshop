#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
print "你好，世界";

s="我是中国人，你呢"

print s

s = s.replace("人", "大人")

print s