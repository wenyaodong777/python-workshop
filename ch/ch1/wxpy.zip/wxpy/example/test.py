#!/usr/bin/python
# -*- coding: UTF-8 -*-

STORY_CONTENT_TEMPLATE = u'[温馨提示] %s建卡啦！\n' \
                         + u'创建时间：%s\n' \
                         + u'故事卡号：%s\n' \
                         + u'简要概述：%s\n' 

s1 = STORY_CONTENT_TEMPLATE % ('1','2','3','4')

print s1
