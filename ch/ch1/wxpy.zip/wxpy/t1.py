#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
print (sys.path)
# import schedule