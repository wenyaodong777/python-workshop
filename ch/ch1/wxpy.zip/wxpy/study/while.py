#!/usr/bin/python
# -*- coding: UTF-8 -*-

chinese_zodiac = '猴鸡狗猪鼠牛虎兔龙蛇马羊'

import time

num = 5
while True:
    print num
    num += 1
    if num > 10:
        break
    time.sleep(1)


ftj















