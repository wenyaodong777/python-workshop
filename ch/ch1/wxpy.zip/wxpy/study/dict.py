dict = {}

print (type(dict))

dict2 = {'x' : 2, 'y' : 1}

dict2['z'] = 3

print dict2