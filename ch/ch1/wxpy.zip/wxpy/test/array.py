
name = ['api' , 'fund']

for a in name:
    print a
